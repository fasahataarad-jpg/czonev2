#!/usr/bin/env bash
set -euo pipefail

# Ubuntu setup for IanUB: installs Node.js 20.x, npm, pm2, then builds and starts the app.

SUDO=""
if [ "${EUID:-$(id -u)}" -ne 0 ] && command -v sudo >/dev/null 2>&1; then
  SUDO="sudo"
fi

echo "Updating package index and installing prerequisites..."
$SUDO apt-get update -y
$SUDO apt-get install -y ca-certificates curl gnupg

echo "Adding NodeSource repository for Node.js 20.x..."
curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | $SUDO gpg --dearmor -o /etc/apt/trusted.gpg.d/nodesource.gpg
NODE_MAJOR=20
echo "deb [signed-by=/etc/apt/trusted.gpg.d/nodesource.gpg] https://deb.nodesource.com/node_$NODE_MAJOR.x nodistro main" | $SUDO tee /etc/apt/sources.list.d/nodesource.list > /dev/null

echo "Installing Node.js $NODE_MAJOR.x, npm, and build essentials..."
$SUDO apt-get update -y
$SUDO apt-get install -y nodejs build-essential

echo "Installing pm2 globally..."
$SUDO npm install -g pm2

echo "Installing project dependencies..."
npm install

echo "Building the project..."
npm run build

PORT=${PORT:-2345}
echo "Starting IanUB on 0.0.0.0:${PORT} with pm2..."
if pm2 describe ianub >/dev/null 2>&1; then
  PORT=${PORT} NODE_ENV=production pm2 restart ianub --update-env
else
  PORT=${PORT} NODE_ENV=production pm2 start server.js --name ianub --interpreter node
fi
pm2 save

read -rp "Do you want to configure HTTPS with a custom domain? (y/N): " USE_DOMAIN
USE_DOMAIN=${USE_DOMAIN,,}

if [[ "${USE_DOMAIN}" == "y" || "${USE_DOMAIN}" == "yes" ]]; then
  read -rp "Enter the domain(s) you want to use (space-separated, e.g., example.com app.example.com): " -a DOMAINS
  if [ "${#DOMAINS[@]}" -eq 0 ]; then
    echo "No domains provided; skipping HTTPS setup."
  else
    read -rp "Enter an email for certificate notifications (Let's Encrypt): " LE_EMAIL

    SERVER_IP=$(curl -s https://ifconfig.me || curl -s https://api.ipify.org || hostname -I 2>/dev/null | awk '{print $1}' || echo "IP_NOT_DETECTED")
    echo
    echo "Create these DNS records BEFORE continuing:"
    for DOMAIN in "${DOMAINS[@]}"; do
      echo "  A  ${DOMAIN}  -> ${SERVER_IP}"
      echo "  A  *.${DOMAIN} -> ${SERVER_IP}  (optional wildcard)"
    done
    echo "Press Enter to continue once DNS is set up."
    read -r

    echo "Installing Caddy (for automatic HTTPS)..."
    $SUDO apt-get install -y debian-keyring debian-archive-keyring
    curl -fsSL https://dl.cloudsmith.io/public/caddy/stable/gpg.key | $SUDO gpg --dearmor -o /etc/apt/trusted.gpg.d/caddy-stable.gpg
    echo "deb [signed-by=/etc/apt/trusted.gpg.d/caddy-stable.gpg] https://dl.cloudsmith.io/public/caddy/stable/deb/debian any-version main" | $SUDO tee /etc/apt/sources.list.d/caddy-stable.list > /dev/null
    $SUDO apt-get update -y
    $SUDO apt-get install -y caddy

    DOMAIN_LIST=$(printf ", %s" "${DOMAINS[@]}")
    DOMAIN_LIST=${DOMAIN_LIST:2}

    echo "Configuring Caddy for: ${DOMAIN_LIST}"
    $SUDO tee /etc/caddy/Caddyfile > /dev/null <<EOF
${DOMAIN_LIST} {
  encode gzip
  reverse_proxy 127.0.0.1:${PORT}
  tls ${LE_EMAIL}
}
EOF

    echo "Restarting Caddy..."
    $SUDO systemctl restart caddy
    $SUDO systemctl enable caddy

    echo "HTTPS setup requested. Caddy will obtain/renew certificates automatically for: ${DOMAIN_LIST}"
  fi
fi

echo "Setup complete. Manage with 'pm2 status', 'pm2 logs ianub', and 'sudo systemctl status caddy' (if enabled)."
