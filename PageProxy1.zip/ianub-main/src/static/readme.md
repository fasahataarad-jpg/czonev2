Loader was taken from V4 and slightly modified for V5 because the developer team was too lazy write one in React.
