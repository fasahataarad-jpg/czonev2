# DogeUB

Vite-powered React front end with a Fastify edge server that bundles Wisp, Bare, and Ultraviolet for proxied browsing plus a fully themeable UI.

![Preview](preview.png)

## Features
- React 19 + Vite 7 with lazy-loaded routes (`/`, `/materials`, `/docs`, `/new`, `/settings`) and GA4 page tracking
- Settings experience for privacy/cloaking, appearance, browsing defaults, and advanced proxy toggles
- Built-in search with quick links, materials/docs libraries, player view, and 404 fallback
- Fastify server that serves the built app, proxies Wisp at `/wisp/`, Bare at `/seal/`, optional MASQR middleware, and relays assets/search suggestions
- Obfuscated production bundles and static asset copying for Bare, Ultraviolet, Scramjet, and libcurl transports

## Prerequisites
- Node.js 18+ recommended
- npm (comes with Node)

## Setup
1. Install dependencies:
   ```bash
   npm install
   ```
2. Copy the example env and adjust as needed:
   ```bash
   cp copy.env .env
   ```
   - `PORT`: port for the Fastify server (default 2345)
   - `BARE`: set to `"false"` to disable the Bare server (e.g., Vercel)
   - `MASQR`: `"true"` to enable MASQR middleware (requires external licensing server)

## Development
- Start the dev server with Vite (includes local proxies for assets/search):
  ```bash
  npm run dev
  ```
  Visit the printed localhost URL.

## Production build
1. Create a production build:
   ```bash
   npm run build
   ```
2. Serve the built assets with the Fastify server:
   ```bash
   node server.js
   ```
   The server hosts `dist/`, wires Wisp/Bare proxies, relays asset requests, and exposes `/return` for DuckDuckGo suggestions and `/ds` for the Discord redirect.

## Scripts
- `npm run dev` � start Vite dev server
- `npm run build` � produce optimized build (`dist/`)
- `npm run preview` � preview the production build locally
- `npm run lint` � run ESLint

## Project structure
- `src/` � React app (routes in `pages/`, UI pieces in `components/`, layout in `layouts/`, theming and options in `styles/` & `utils/`)
- `server.js` � Fastify host + Bare/Wisp proxies and asset/search endpoints
- `vite.config.js` � Vite setup with bundle obfuscation, static copies for proxy assets, and dev-time middleware
- `copy.env` � environment variable template
